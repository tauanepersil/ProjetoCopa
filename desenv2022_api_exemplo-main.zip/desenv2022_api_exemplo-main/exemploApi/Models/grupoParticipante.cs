﻿namespace exemploApi.Models
{
    public class grupoParticipante
    {
        public int GrupoID { get; set; }
        public int participantesID { get; set; }
    }
}
