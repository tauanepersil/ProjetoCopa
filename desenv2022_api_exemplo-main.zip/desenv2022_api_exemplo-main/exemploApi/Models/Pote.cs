﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace exemploApi.Models
{
    public class Pote
    {
        public int PoteID { get; set; }

        public string descricao { get; set; }
    }
}
