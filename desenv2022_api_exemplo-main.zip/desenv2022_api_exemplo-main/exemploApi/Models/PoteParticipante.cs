﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace exemploApi.Models
{
    public class PoteParticipante
    {
        public int PoteID { get; set; }
        public int participantesID { get; set; }
    }
}
