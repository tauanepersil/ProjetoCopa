﻿namespace exemploApi.Models
{
    public class grupo
    {
        public int GrupoID { get; set; }
        public string descricao { get; set; }
    }
}
