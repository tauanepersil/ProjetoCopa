﻿namespace exemploApi.Models
{
    public class confederacao
    {
        public int confederacaoID { get; set; }
        public string sigla { get; set; }
        public string nome { get; set; }
    }
}
