﻿namespace exemploApi.Models
{
    public class participante
    {
        public int participantesID { get; set; }
        public string nome { get; set; }
        public bool sede { get; set; }
        public int rankingFifa { get; set; }
        public int cofederacaoID { get; set; }


    }
}
