﻿using exemploApi.Models;
using exemploApi.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace exemploApi.Controllers
{
	[Route("api/[controller]")]
	public class PoteController : Controller
	{

		private readonly IPoteRepository _repository;
		private readonly IPoteParticipanteRepository _poteRepository;

		public PoteController(IPoteRepository repository, IPoteParticipanteRepository PoteParticipanteRepository)
		{
			_repository = repository;
			_poteRepository = PoteParticipanteRepository;

		}

		[HttpGet]
		[Route("ola")]
		public async Task<ActionResult> ola()
		{
			return Ok("Ola API ON!");
		}

		[HttpGet]
		[Route("ObterTodos")]
		public async Task<ActionResult<IEnumerable<Pote>>> ObterTodos()
		{

			var Pote = await _repository.ObterTodos();

			if (Pote == null)
			{
				return NotFound();
			}

			return Ok(Pote);
		}

		[HttpGet]
		[Route("ObterParticipantesPorPote/{id}")]
		public async Task<ActionResult<IEnumerable<Pote>>> ObterParticipantesPorPote(int id)
		{

			var participantesDoPote = await _poteRepository.ObterTodos(id);

			return Ok(participantesDoPote);
		}


		[HttpGet]
		[Route("ObterPorId/id")]
		public async Task<ActionResult<IEnumerable<Pote>>> ObterPorId(int id)
		{

			var participante = await _repository.ObterPorId(id);

			if (participante == null)
			{
				return NotFound();
			}

			return Ok(participante);
		}

		[HttpPost]
		[Route("Adicionar")]
		public async Task<ActionResult<IEnumerable<Pote>>> Adicionar(Pote p)
		{

			if (p == null)
			{
				return BadRequest();
			}

			await _repository.Adicionar(p);

			return Ok("Participante cadastro com sucesso");
		}

		[HttpPost]
		[Route("AdicionarPote")]
		public async Task<ActionResult<IEnumerable<Pote>>> AdicionarPote(PoteParticipante p)
		{

			if (p == null)
			{
				return BadRequest();
			}

			await _poteRepository.Adicionar(p);

			return Ok("Participante cadastro com sucesso");
		}

		[HttpPut]
		[Route("Atualizar/id")]
		public async Task<ActionResult<IEnumerable<Pote>>> Atualizar(int id, Pote p)
		{
			var participanteAux = _repository.ObterPorId(id);

			if (participanteAux == null)
			{
				return NotFound();
			}
			p.PoteID = id;
			await _repository.Atualizar(p);

			return Ok("Participante atualizado com sucesso");
		}


		[HttpDelete]
		[Route("Deletar/id")]
		public async Task<ActionResult<IEnumerable<Pote>>> Deletar(int id)
		{
			var participanteAux = _repository.ObterPorId(id);

			if (participanteAux == null)
			{
				return NotFound();
			}

			_repository.Deletar(id);

			return Ok("Participante deletado com sucesso");

		}

	}
}
