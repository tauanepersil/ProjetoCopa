﻿using exemploApi.Models;
using exemploApi.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace exemploApi.Controllers
{

/*	public class AlunoController : Controller
	{
		private readonly IAlunoRepository _repository;

		public AlunoController(IAlunoRepository repository)
		{
			_repository = repository;
		}


		[HttpGet]
		public async Task<ActionResult<IEnumerable<Aluno>>> GetProdutos()
		{
			var alunos = await _repository.ObterTodos();
			if (alunos == null)
			{
				return BadRequest();
			}
			return Ok(alunos);
		}
	}
*/
}
