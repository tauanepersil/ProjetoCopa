﻿using Microsoft.AspNetCore.Mvc;

namespace exemploApi.Controllers
{
    public class SorteioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
